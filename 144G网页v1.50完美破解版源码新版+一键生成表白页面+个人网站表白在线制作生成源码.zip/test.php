<?php   
//PHP计算两个时间差的方法 
//$startdate=date("y-m-d H:i:s");
//$enddate="2017-5-9 20:50:00";
//$date=floor((strtotime($enddate)-strtotime($startdate))/86400);
//$hour=floor((strtotime($enddate)-strtotime($startdate))%86400/3600);
//$minute=floor((strtotime($enddate)-strtotime($startdate))%86400/60);
//$second=floor((strtotime($enddate)-strtotime($startdate))%86400%60);
//echo $date."天<br>";
//echo $hour."小时<br>";
//echo $minute."分钟<br>";
//echo $second."秒<br>";
for($i=0;$i<100;$i++){
	file_get_contents('http://www.144g.com/?ii=123');
	}


?>
