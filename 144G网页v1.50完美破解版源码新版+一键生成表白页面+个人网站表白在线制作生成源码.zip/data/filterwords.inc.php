<?php
if(!defined('PATH_ROOT')){
	exit('Access Denied');
}
return '淫娃|傻逼|他娘的|aaa|asd|asdasd';
?>